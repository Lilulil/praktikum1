<?php
var_dump($_GET);
var_dump(date("Y年m月d日 H時i分s秒", time()));
