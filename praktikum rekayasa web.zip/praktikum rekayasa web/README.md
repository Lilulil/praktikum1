# lara-docker

This is develop environments for me. using nginx + php-fpm + MySQL + Node.js with docker.

## versions

- PHP: 7.3
- nginx: 1.17
- MySQL: 8.0
- Node.js: 12.14

## Usage

```
$ docker-sync start // docker-sync

$ docker-compose build
$ docker-compose up
```

### docker-sync

```
# install
$ sudo gem install docker-sync

# brew install fswatch unison eugenmayer/dockersync/unox
```

## License

MIT
